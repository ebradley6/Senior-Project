/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: cppUpshifter_terminate.c
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 26-Apr-2016 01:35:08
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "cppUpshifter.h"
#include "cppUpshifter_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void cppUpshifter_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for cppUpshifter_terminate.c
 *
 * [EOF]
 */
