//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: cppUpshifter_initialize.cpp
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 26-Apr-2016 01:18:05
//

// Include Files
#include "rt_nonfinite.h"
#include "cppUpshifter.h"
#include "cppUpshifter_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void cppUpshifter_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for cppUpshifter_initialize.cpp
//
// [EOF]
//
