//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: cppUpshifter_terminate.h
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 26-Apr-2016 01:18:05
//
#ifndef __CPPUPSHIFTER_TERMINATE_H__
#define __CPPUPSHIFTER_TERMINATE_H__

// Include Files
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "cppUpshifter_types.h"

// Function Declarations
extern void cppUpshifter_terminate();

#endif

//
// File trailer for cppUpshifter_terminate.h
//
// [EOF]
//
